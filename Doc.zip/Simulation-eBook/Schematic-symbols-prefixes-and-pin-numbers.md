# Schematic symbols: prefixes and pin numbers 
[Schematic symbols: prefixes and pin numbers](http://easyeda.com/Doc/Tutorial/prefix.htm) 
  