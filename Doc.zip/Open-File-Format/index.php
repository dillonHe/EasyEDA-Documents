<?php
if(isset($_GET["file"])){
	# Get Markdown class
	require_once(dirname(__File__).'/../Parsedown/Parsedown.php');
	$Parsedown = new Parsedown(!true, true);
	echo <<<EOT
<!DOCTYPE html>
<html>
<head>
<title>common</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../css/prettify.css" />
<link rel="stylesheet" href="../css/marddownPad.css" />
<script type="text/javascript" src="../css/prettify.js"></script>
		</head>
	<body>
EOT;

echo $Parsedown->text(file_get_contents("./$_GET[file]"));
echo <<<EOT
<script>
     window.onload = function(){
    /*prettify代码高亮*/
    window.prettyPrint && prettyPrint();
    };
	</script>
	</body>
		</html>
EOT;


}else{
	$files = scandir('./');
	foreach($files as $file){
		if(stripos( $file, '.md' )){
			echo <<<EOT
			<li><a href="./index.php?file=$file" target="_blank">$file</a>
EOT;
		}
	}
}
exit();

