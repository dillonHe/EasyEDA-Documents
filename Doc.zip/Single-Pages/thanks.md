
#Thank You List!

 EasyEDA gets help from many people, ranging from ideas and suggestions to products, but the following people and organizations really spend lots of time and energy to help EasyEDA out.

1. Richard Dudley (Doudou), an audio designer and teacher, supporting the EasyEDA team from the beginning.
2. Signality Solutions, electronics engineering consultancy, expertise and training in Analysis, Design, Modelling and Simulation. Helping EasyEDA to create some awesome tutorials and spice models. http://signality.co.uk/
3. Sancho, an electronic hobbyist, trying to help EasyEDA to be easy and bug free
4. JI YI SUI PIAN, a PCB layout engineer, has used EasyEDA to reproduce lots of Arduino products
5. Andrew, translated EasyEDA from English to Polish. http://and.elektroda.eu/
6. A.Noda, translated EasyEDA from English to Japanese language. http://signalkhobho.com/
7. JM TERRADE, translated EasyEDA from English to French language. http://terrade.com/
8. José Miguel, translated EasyEDA from English to Spanish language.
9. Kent Ahlberg, translated EasyEDA from English to Swedish language.
10. Marcel Kuesters, translated EasyEDA from English to German language.

**Keep checking back, we have a feeling this list will keep on growing... **
